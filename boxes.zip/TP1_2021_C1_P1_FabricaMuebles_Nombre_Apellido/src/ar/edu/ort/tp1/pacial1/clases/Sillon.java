package ar.edu.ort.tp1.pacial1.clases;

public class Sillon extends Mueble {

	private int cantCuerpos;
	private TelaSillon tela;
	
	public Sillon(String modelo, float costoBase, float porcentajeGanancia, int cantCuerpos, TelaSillon tela) {
		super(modelo, costoBase, porcentajeGanancia);
		this.tela = tela;
		this.cantCuerpos = cantCuerpos;
	}

	@Override
	public void mostrar() {
		System.out.println("Tipo: Sillon" + ", Modelo: " + super.getModelo() + ", precio venta: " + super.calcularPrecioVenta());
	}

	@Override
	public float calcularPrecioCosto() {

		
//		● Para los sillones el costo se calcula como la multiplicación del costo base por la cantidad de
//		cuerpos por un porcentaje definido para el tipo de tela pedido
//		(costo base * cantidad de cuerpos * porcentaje adicional por tela)
		
		return super.getCostoBase() * this.cantCuerpos * tela.getPorcentaje(); 
	}
}
