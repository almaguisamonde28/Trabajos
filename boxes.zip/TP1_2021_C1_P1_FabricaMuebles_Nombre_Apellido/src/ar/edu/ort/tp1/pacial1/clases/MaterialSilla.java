package ar.edu.ort.tp1.pacial1.clases;

public enum MaterialSilla {

	MADERA, METAL, PLASTICO;
	
}
