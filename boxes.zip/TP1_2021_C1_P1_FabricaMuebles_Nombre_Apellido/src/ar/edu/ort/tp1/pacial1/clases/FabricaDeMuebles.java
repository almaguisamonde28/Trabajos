package ar.edu.ort.tp1.pacial1.clases;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;

public class FabricaDeMuebles implements Mostrable {

	private String nombre;
	private ArrayList<Mueble> mueblesFabricados;

	
	public FabricaDeMuebles(String nombre) {
		this.nombre = nombre;
		this.mueblesFabricados = new ArrayList<Mueble>();
	}

	public boolean fabricar(Mueble mueble) {
		
		boolean fabricado = seHaFabricado(mueble.getModelo());
		
		if(!fabricado){
			mueblesFabricados.add(mueble);
			
			System.out.println("Fabricando el mueble:");
			mueble.mostrar();
			
		}
		
		
		
		return fabricado;
	}

	@Override
	public void mostrar() {

//		F�brica de muebles: S�per F�brica 2000
//		Se han fabricado: 4 Mesas, 3 Sillas y 5 Sillones
//		La venta total fue: $52115,34
		
		int contadorMesa    = 0;
		int contadorSilla   = 0;
		int contadorSillon  = 0;
		float sumaDeVentas  = 0;
		
		for (Mueble mueble : mueblesFabricados) {

			 if (mueble instanceof Silla) 
				 contadorSilla++; 
			 
			 if (mueble instanceof Sillon) {
				 contadorSillon++;
			 } else if (mueble instanceof Mesa) {
				 contadorMesa++;
			 }
			
			 sumaDeVentas += mueble.calcularPrecioVenta();
		}
		
		System.out.println("Fabrica de Muebles : " + this.nombre);
		System.out.println("Se han fabricado : " + contadorMesa + " Mesas");
		System.out.println("Se han fabricado : " + contadorSilla + " Sillas");
		System.out.println("Se han fabricado : " + contadorSillon + " Sillones");
		System.out.println("La venta total fue : " + sumaDeVentas );
	}
	
	
	

	public boolean seHaFabricado(String modelo) {

		boolean seHaFabricado  = false;
		int indiceIteracion = 0;
		
		while(!seHaFabricado && indiceIteracion < mueblesFabricados.size()) {
			
			if(mueblesFabricados.get(indiceIteracion).getModelo().equals(modelo)) {
				seHaFabricado = true;
			}
			
			indiceIteracion++;
		}
		
		return seHaFabricado;
	}
}
