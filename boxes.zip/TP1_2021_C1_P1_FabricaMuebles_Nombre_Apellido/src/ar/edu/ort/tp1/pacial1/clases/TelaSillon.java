package ar.edu.ort.tp1.pacial1.clases;

public enum TelaSillon {

	CHENILLE(20f,"Argentina"), PANA(15f,"Espa�a"), GOBELINO(17f,"Chile");

	private float porcentaje;
	public String paisOrigen;

	private TelaSillon(float porcentaje, String paisOrigen) {
		this.porcentaje = porcentaje;
		this.paisOrigen = paisOrigen;
	}

	public float getPorcentaje() {
		return porcentaje;
	}

}
