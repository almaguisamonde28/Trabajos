package ar.edu.ort.tp1.pacial1.clases;

public class Silla extends Mueble {

	private static final int COEFICIENTE_SILLA = 3;
	
	private int alto;
	private MaterialSilla material;
	
	public Silla(String modelo, float costoBase, float porcentajeGanancia, int alto) {
		super(modelo, costoBase, porcentajeGanancia);
		this.alto = alto;		
//		this.material = material;
	}
	
	
	@Override
	public void mostrar() {
		System.out.println("Tipo: Silla" + ", Modelo: " + super.getModelo() + ", precio venta: " + super.calcularPrecioVenta());
		
	}
	@Override
	public float calcularPrecioCosto() {
		
//		El costo de los muebles depende del tipo de mueble.
//		
//		(costo base * multiplicador del tipo de mesa + 0.2 * largo * ancho)
//		
//		(costo base + multiplicador del material * alto)

		return super.getCostoBase() + (this.alto * COEFICIENTE_SILLA );
	}
	

}
