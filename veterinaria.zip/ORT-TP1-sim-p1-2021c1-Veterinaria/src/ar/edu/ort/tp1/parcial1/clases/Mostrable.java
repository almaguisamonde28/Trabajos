package ar.edu.ort.tp1.parcial1.clases;

public interface Mostrable {
	void mostrar();
}
