package parcial1.clases;

public class OpcionDeSalida extends OpcionDeMenu {

	public OpcionDeSalida() {
		super("Salir", 'X');
	}
	
	@Override
	public void ejecutar() {
		// NO HACE NADA, SOLO SE COMPLETA PARA CUMPLIR CON LA INTERFAZ
	}
}
