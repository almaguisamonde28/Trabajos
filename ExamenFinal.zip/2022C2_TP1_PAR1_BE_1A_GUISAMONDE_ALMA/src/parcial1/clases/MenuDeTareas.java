package parcial1.clases;

import java.util.ArrayList;
import java.util.Scanner;

public class MenuDeTareas extends Menu {
	private ArrayList<OpcionOnOff> opciones;

	public MenuDeTareas(String titulo, Scanner input) {
		super(titulo, input);
		this.opciones = new ArrayList<OpcionOnOff>();
	}

	public void registrar(OpcionOnOff opcion) {
		opciones.add(opcion);
	}

	public int getTotalTareasCumplidas() {
		int cantActivas = 0;
		for (OpcionOnOff opcionOnOff : opciones) {
			if (opcionOnOff.estaActivada()) {
				cantActivas++;
			}
		}
		return cantActivas;
	}

}
