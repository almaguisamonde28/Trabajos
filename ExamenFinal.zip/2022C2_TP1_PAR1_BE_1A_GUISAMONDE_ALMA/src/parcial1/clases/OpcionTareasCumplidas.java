package parcial1.clases;

import java.util.ArrayList;

public class OpcionTareasCumplidas extends OpcionDeMenu {

	private ArrayList<MenuDeTareas> menuDeTareas;

	public OpcionTareasCumplidas(String descripcion, char charSelector, MenuDeTareas menuSecundario) {
		super(descripcion, charSelector);
		this.menuDeTareas = new ArrayList<MenuDeTareas>();
	}

	@Override
	public void ejecutar() {
		for (MenuDeTareas menuDeTareas : menuDeTareas) {
			if (menuDeTareas instanceof MenuDeTareas) {
				menuDeTareas.getTotalTareasCumplidas();
			}
		}

	}

}
