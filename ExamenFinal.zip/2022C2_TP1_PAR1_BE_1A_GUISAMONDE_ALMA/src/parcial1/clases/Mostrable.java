package parcial1.clases;

public interface Mostrable {
	void mostrar();
}
