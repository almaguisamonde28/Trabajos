package parcial1.clases;

public interface Activable {

	boolean activar();

	boolean desactivar();

	boolean estaActivada();
}
