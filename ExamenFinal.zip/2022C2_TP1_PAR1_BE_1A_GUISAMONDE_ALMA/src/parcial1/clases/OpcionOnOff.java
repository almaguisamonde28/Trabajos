package parcial1.clases;

public class OpcionOnOff extends OpcionDeMenu implements Activable {

	final static String OPCION_ACTIVA = "[ X ]";
	final static String OPCION_INACTIVA = "[  ]";
	private boolean estadoInicial = false;

	public OpcionOnOff(String descripcion, char charSelector) {
		super(descripcion, charSelector);

	}

	public OpcionOnOff(String descripcion, char charSelector, boolean estadoInicial) {
		super(descripcion, charSelector);
		setEstadoInicial(estadoInicial);

	}

	@Override
	public void mostrar() {
		if (estaActivada()) {
			System.out.println(OPCION_ACTIVA);
		} else {
			System.out.println(OPCION_INACTIVA);
		}

	}

	@Override
	public void ejecutar() {
		if (!estaActivada()) {
			activar();
		} else {
			desactivar();
		}
	}

	@Override
	public boolean activar() {
		return true;
	}

	@Override
	public boolean desactivar() {
		return true;
	}

	@Override
	public boolean estaActivada() {
		return true;
	}

	public boolean isEstadoInicial() {
		return estadoInicial;
	}

	public void setEstadoInicial(boolean estadoInicial) {
		this.estadoInicial = estadoInicial;
	}

}
