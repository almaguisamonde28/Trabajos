package ejercicioTrenes;

public class Vagon {
	private TipoVagon tipo;
	private int carga;

	public Vagon(TipoVagon tipo) {
		setTipo(tipo);
	}

	public int capacidadMaxima() {
		int capacidadMaxima = 0;
		switch (tipo) {
		case SMALL:
			capacidadMaxima = 30;
			break;
		case MEDIUM:
			capacidadMaxima = 40;
			break;
		case LARGE:
			capacidadMaxima = 50;
			break;
		}
		return capacidadMaxima;
	}

	public int capacidadLibre() {
		return capacidadMaxima() - carga;
	}

	public int cargarVagon(int cantidad) {
		int espacionLibre = capacidadMaxima() - cantidad;
		int aCargar = Math.min(cantidad, espacionLibre);
		carga += aCargar;
		return cantidad;
	}

	public boolean estaLleno() {
		return carga == capacidadMaxima();
	}

	public boolean estaVacio() {
		return carga == 0;
	}

	public TipoVagon getTipo() {
		return tipo;
	}

	private void setTipo(TipoVagon tipo) {
		this.tipo = tipo;
	}

}
