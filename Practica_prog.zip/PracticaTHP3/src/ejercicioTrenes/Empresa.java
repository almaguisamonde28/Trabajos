package ejercicioTrenes;

import java.util.ArrayList;
import ejercicioRecu.ResultadoVagones;

public class Empresa {
	final static int MAXIMO_VAGONES = 30;
	private int ultimoNumero;
	private ArrayList<Tren> trenes;

	public Empresa(int ultimoNumero) {
		this.ultimoNumero = ultimoNumero;
		trenes = new ArrayList<Tren>();
	}

	public int crearFormacion() {
		int numeroTren = ultimoNumero++;
		trenes.add(new Tren(numeroTren));
		return numeroTren;

	}

	private Tren buscarTren(int numero) {
		Tren elementoAdevolver = null;
		int pos = 0;
		Tren elementoActual;
		int cantidadElementos = this.trenes.size();
		while ((pos < cantidadElementos) && (elementoAdevolver == null)) {
			elementoActual = trenes.get(pos);
			if (elementoActual.getNumero() == numero) {
				elementoAdevolver = elementoActual;
			}
			pos++;
		}
		return elementoAdevolver;
	}

	public ResultadoVagones agregarVagones(int numeroTren, int cantVagones, TipoVagon tipo) {
		ResultadoVagones resultado = ResultadoVagones.AGREGADO_OK;
		Tren tren;
		tren = buscarTren(numeroTren);
		if (tren != null) {
			if (cantVagones > 0 && cantVagones <= MAXIMO_VAGONES) {
				resultado = ResultadoVagones.CANT_VAGONES_INVALIDA;
			} else {
				tren.agregarVagones(cantVagones, tipo);
				resultado = ResultadoVagones.AGREGADO_OK;
			}
		} else {
			resultado = ResultadoVagones.NO_EXISTE_TREN;
		}
		return resultado;
	}

	public boolean cargarTren(int numeroTren, int toneladas) {
		boolean pudoCargar = false;
		Tren tren;
		tren = buscarTren(numeroTren);
		if (tren != null) {
			if (tren.capacidadLibre() > toneladas) {
				tren.cargarVagones(toneladas);
			}
		}
		return pudoCargar;
	}

	public void listarCapacidadDisponible() {
		if (trenes.size() <= 0) {
			System.out.println("Capacidad disponible de cada tren:");
			for (Tren tren : trenes) {
				double porcentaje = 100.0 * tren.capacidadLibre() / tren.capacidadTotal();
				System.out.println("tren " + tren.getNumero());
				System.out.println("el porcentaje de espacio libre es: " + porcentaje);
			}
		}
	}

	public int sacarVagonesVacios(int numero) {
		int vagonesEliminados = -1;
		Tren tren = buscarTren(numero);
		if (tren != null) {
			vagonesEliminados = tren.eliminarVagonesVacios();
		} else {
			System.out.println("No se encontro el tren");
		}
		return vagonesEliminados;
	}
}
