package ejercicioTrenes;

import java.util.ArrayList;

public class Tren {
	private ArrayList<Vagon> vagones;
	private int numero;

	public Tren(int numero) {
		setNumero(numero);
		vagones = new ArrayList<Vagon>();
	}

	public boolean agregarVagones(int cantidad, TipoVagon tipo) {
		boolean seAgrego = false;
		for (Vagon vagon : vagones) {
			vagon = new Vagon(tipo);
			vagones.add(vagon);
			seAgrego = true;
		}

		return seAgrego;
	}

	public int capacidadTotal() {
		int capacidadTotal = 0;
		for (Vagon vagon : vagones) {
			capacidadTotal += vagon.capacidadMaxima();
		}
		return capacidadTotal;
	}

	public int capacidadLibre() {
		int capacidadLibre = 0;
		for (Vagon vagon : vagones) {
			capacidadLibre += vagon.capacidadLibre();
		}
		return capacidadLibre;
	}

	public int cargarVagones(int carga) {
		int index = 0;
		while (index < this.vagones.size() && carga > 0) {
			Vagon vagon = vagones.get(index);
			if (!vagon.estaLleno()) {
				vagon.cargarVagon(carga);
			}
		}
		return carga;
	}

	public int eliminarVagonesVacios() {
		int vagonesEliminados = 0;
		int index = 0;
		while (index < vagones.size()) {
			if (vagones.get(index).estaVacio()) {
				vagones.remove(index);
				vagonesEliminados++;
			} else {
				index++;
			}
		}
		return vagonesEliminados;
	}

	public int getNumero() {
		return numero;
	}

	private void setNumero(int numero) {
		this.numero = numero;
	}

}
