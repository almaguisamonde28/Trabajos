package ejercicioTrenes;

public enum TipoVagon {

	SMALL, MEDIUM, LARGE
}
