package ejercicioRecu;

import java.util.ArrayList;

public class Aplicacion {

	private ArrayList<Persona> clientes;

	public Aplicacion() {
		clientes = new ArrayList<Persona>();
	}

	private Persona buscarPersona(String dni) {
		Persona elementoAdevolver = null;
		int pos = 0;
		Persona elementoActual;
		int cantidadElementos = this.clientes.size();
		while ((pos < cantidadElementos) && (elementoAdevolver == null)) {
			elementoActual = clientes.get(pos);
			if (elementoActual.getDni().equals(dni)) {
				elementoAdevolver = elementoActual;
			}
			pos++;
		}
		return elementoAdevolver;
	}

	public boolean agregarCliente(String dni) {
		boolean seAgrego = false;
		Persona cliente;
		cliente = buscarPersona(dni);

		if (cliente != null) {
			cliente = new Persona(dni);
			clientes.add(cliente);
			seAgrego = true;
		} else {
			System.out.println("El cliente ya existe");
		}

		return seAgrego;
	}

	public boolean registrarTarjeta(String dni, TipoTarjeta tipo, String numero, int montoDisponible) {
		boolean seRegistro = false;
		Persona cliente = null;
		Tarjeta tarjeta;
		cliente = buscarPersona(dni);
		tarjeta = cliente.buscarTarjeta(tipo);
		while ((cliente != null) && (tarjeta == null)) {
			tarjeta = new Tarjeta(numero, tipo, montoDisponible);
			seRegistro = true;
		}

		return seRegistro;
	}

	public void mostrarTarjetasPuedenComprar(String dni, int cantComprasRealizadas) {

		for (Persona persona : clientes) {
			persona = buscarPersona(dni);
			if (persona != null) {
				persona.puedeRealizarCompra(cantComprasRealizadas);
			}
		}
	}

	public void mostrarTarjetasConSaldo() {
		for (Persona persona : clientes) {
			clientes.size();
			persona.mostrarTarjetaConSaldo();
			;
		}
	}

	public void obtenerCompras() {
		for (Persona persona : clientes) {
			persona.getDni();
			persona.getCantComprasRealizadas();
		}
	}

	public ResultadoOperacion realizarCompra(String dni, int monto, int cantCuotas) {
		ResultadoOperacion resultado = ResultadoOperacion.TRANSACCION_OK;
		Persona cliente;
		cliente = buscarPersona(dni);
		if (cliente == null) {
			resultado = ResultadoOperacion.USUARIO_INEXISTENTE;
		} else if (monto <= 0 || cantCuotas <= 0) {
			resultado = ResultadoOperacion.ERROR;
		} else {
			Tarjeta tarjetaMayorSaldo = cliente.mostrarTarjetasConMayorSaldo();
			if (tarjetaMayorSaldo == null || tarjetaMayorSaldo.getMontoDisponible() > monto) {
				resultado = ResultadoOperacion.SIN_TARJETA_PARA_COMPRA;
			} else {
				if (!tarjetaMayorSaldo.comprar(monto)) {
					resultado = ResultadoOperacion.SIN_TARJETA_PARA_COMPRA;
				} else {
					cliente.registrarCompra();
				}

			}
		}

		return resultado;

	}

	public void comprar(String dni, int monto, int cantCuotas) {
		ResultadoOperacion resultado = this.realizarCompra(dni, monto, cantCuotas);
		if (resultado == ResultadoOperacion.TRANSACCION_OK) {
			System.out.println("La compra fue realizada por:" + dni);
			System.out.println("El monto es de:" + monto);
			System.out.println("Las cuotas son: " + cantCuotas);
		}
	}

}
