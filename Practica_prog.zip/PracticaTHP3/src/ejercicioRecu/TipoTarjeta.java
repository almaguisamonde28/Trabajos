package ejercicioRecu;

public enum TipoTarjeta {
	YATAYPLUS, MONTACARD, INSTICARD

}
