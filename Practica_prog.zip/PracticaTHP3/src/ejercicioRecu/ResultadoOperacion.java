package ejercicioRecu;

public enum ResultadoOperacion {

	TRANSACCION_OK, SIN_TARJETA_PARA_COMPRA, USUARIO_INEXISTENTE, ERROR;
}
