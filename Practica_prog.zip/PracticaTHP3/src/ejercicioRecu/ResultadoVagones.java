package ejercicioRecu;

public enum ResultadoVagones {
	NO_EXISTE_TREN, CANT_VAGONES_INVALIDA, AGREGADO_OK
}
