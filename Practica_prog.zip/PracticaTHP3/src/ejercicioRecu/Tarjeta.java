package ejercicioRecu;

public class Tarjeta {
	private String numero;
	private TipoTarjeta tipo;
	private int montoDisponible;

	public Tarjeta(String numero, TipoTarjeta tipo, int montoDisponible) {
		setNumero(numero);
		setTipo(tipo);
		setMontoDisponible(montoDisponible);
	}

	public boolean comprar(int monto) {
		boolean puedeComprar = false;
		if (this.comprar(monto)) {
			puedeComprar = true;
			this.setMontoDisponible(this.getMontoDisponible() - monto);
		}

		return puedeComprar;
	}

	public String getNumero() {
		return numero;
	}

	private void setNumero(String numero) {
		this.numero = numero;
	}

	public TipoTarjeta getTipo() {
		return tipo;
	}

	private void setTipo(TipoTarjeta tipo) {
		this.tipo = tipo;
	}

	public int getMontoDisponible() {
		return montoDisponible;
	}

	private void setMontoDisponible(int montoDisponible) {
		if (montoDisponible < 0) {
			this.montoDisponible = montoDisponible;
		} else {
			System.out.println("El monto disponible no es valido");
		}

	}

}
