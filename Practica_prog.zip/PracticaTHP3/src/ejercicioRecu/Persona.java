package ejercicioRecu;

import java.util.ArrayList;

public class Persona {
	private ArrayList<Tarjeta> tarjetas;
	private String dni;
	private int cantComprasRealizadas = 0;

	public Persona(String dni) {
		setDni(dni);
		tarjetas = new ArrayList<Tarjeta>();
	}

	public ArrayList<Tarjeta> getTarjetas() {
		return tarjetas;
	}

	public Tarjeta buscarTarjeta(TipoTarjeta tipo) {
		Tarjeta elementoAdevolver = null;
		int pos = 0;
		Tarjeta elementoActual;
		int cantidadElementos = this.tarjetas.size();
		while ((pos < cantidadElementos) && (elementoAdevolver == null)) {
			elementoActual = tarjetas.get(pos);
			if (elementoActual.getTipo().equals(tipo)) {
				elementoAdevolver = elementoActual;
			}
			pos++;
		}
		return elementoAdevolver;
	}

	public boolean puedeRealizarCompra(int cantComprasRealizadas) {
		boolean puede = false;
		Tarjeta tarjeta = null;
		if (tarjeta.getMontoDisponible() > cantComprasRealizadas) {
			tarjeta.getTipo();
			tarjeta.getMontoDisponible();
			tarjeta.getNumero();
			puede = true;
		}
		return puede;
	}

	public void mostrarTarjetaConSaldo() {
		for (Tarjeta tarjeta : tarjetas) {
			if (tarjeta.getMontoDisponible() > 0) {
				System.out.println(tarjeta);
			}
		}
	}

	public Tarjeta mostrarTarjetasConMayorSaldo() {
		Tarjeta tarjetaMayorSaldo = null;
		int saldo;
		for (Tarjeta tarjeta : tarjetas) {
			if (tarjeta.getMontoDisponible() > 0) {
				saldo = tarjeta.getMontoDisponible();
				tarjetaMayorSaldo = tarjeta;
			}
		}
		return tarjetaMayorSaldo;
	}

	public void registrarCompra() {
		this.setCantComprasRealizadas(this.getCantComprasRealizadas() + 1);
	}

	private void setTarjetas(ArrayList<Tarjeta> tarjetas) {
		this.tarjetas = tarjetas;
	}

	public String getDni() {
		return dni;
	}

	private void setDni(String dni) {

		this.dni = dni;
	}

	public int getCantComprasRealizadas() {
		return cantComprasRealizadas;
	}

	private void setCantComprasRealizadas(int cantComprasRealizadas) {
		this.cantComprasRealizadas = cantComprasRealizadas;
	}

}
