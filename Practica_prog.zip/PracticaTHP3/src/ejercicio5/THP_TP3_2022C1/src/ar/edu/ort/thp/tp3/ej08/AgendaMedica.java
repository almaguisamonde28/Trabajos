package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej08;

import java.util.ArrayList;

public class AgendaMedica {

	private ArrayList<Turno> turnos;
	private int cantidadTurnos;

	public AgendaMedica(int cantidadTurnos) {
		turnos = new ArrayList<>();
		setCantidadTurnos(cantidadTurnos);
	}

	public boolean anularTurno(int dni) {
		boolean pudeAnular = false;
		Turno turno = buscarTurno(dni);

		if (turno != null) {
			pudeAnular = turnos.remove(turno);
		}

		return pudeAnular;
	}

	private Turno buscarTurno(int dni) {
		Turno turnoABuscar = null;
		int i = 0;

		while (turnoABuscar == null && i < turnos.size()) {

			if (turnos.get(i).mismoPaciente(dni)) {
				turnoABuscar = turnos.get(i);
			} else {
				i++;
			}
		}
		return turnoABuscar;
	}

	public boolean darPresente(int dni) {
		boolean pudeDarPresente = false;
		Turno turno = buscarTurno(dni);

		if (turno != null) {
			turno.darPresente();
			pudeDarPresente = true;
		}

		return pudeDarPresente;
	}

	public void listarTurnos() {
		if (turnos.size() > 0) {
			System.out.println("Cantidad de turnos asignados hasta el momento: " + turnos.size());
			for (Turno turno : turnos) {
				System.out.println(turno);
			}
		} else {
			System.out.println("No hay turnos asignados");
		}
	}

	public ArrayList<Paciente> obtenerAusentes() {
		ArrayList<Paciente> pacientes = new ArrayList<>();

		for (Turno turno : turnos) {
			if (!turno.estaPresente()) {
				pacientes.add(turno.getPaciente());
			}
		}
		return pacientes;

	}

	public ResultadoRegistracion registrarTurno(int dni, String apellido, String nombre, String telefono) {

		ResultadoRegistracion resultado = ResultadoRegistracion.ERROR_TURNOS_COMPLETOS;

		if (turnos.size() < cantidadTurnos) {
			if (buscarTurno(dni) == null) {
				Paciente paciente = new Paciente(dni, apellido, nombre, telefono);
				turnos.add(new Turno(paciente));
				resultado = ResultadoRegistracion.TURNO_CONFIRMADO;
			} else {
				resultado = ResultadoRegistracion.ERROR_YA_TIENE_TURNO;
			}
		}

		return resultado;
	}

	private void setCantidadTurnos(int cantidadTurnos) {
		this.cantidadTurnos = cantidadTurnos;
	}

}