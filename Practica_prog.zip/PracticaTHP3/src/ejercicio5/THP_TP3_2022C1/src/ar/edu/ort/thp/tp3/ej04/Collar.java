package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej04;

public class Collar {

	private String chapita;
	
	public Collar(String chapita) {
		setChapita(chapita);
	}
	
	private void setChapita(String chapita) {
		this.chapita = chapita;
	}

	public String getChapita() {
		return chapita;
	}

}

