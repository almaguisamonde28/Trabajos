package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej06;

public enum ResulAlta {
	CLIENTE_EXISTENTE, CLIENTE_DEUDOR, ALTA_OK
}