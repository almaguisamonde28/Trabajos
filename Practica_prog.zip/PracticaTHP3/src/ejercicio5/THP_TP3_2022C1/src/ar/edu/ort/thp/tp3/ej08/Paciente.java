package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej08;

public class Paciente {
	private int dni;
	private String apellido;
	private String nombre;
	private String telefono;


	public Paciente(int dni, String apellido, String nombre, String telefono) {
		setDni(dni);
		setApellido(apellido);
		setNombre(nombre);
		setTelefono(telefono);
	}

	public String getApellido() {
		return apellido;
	}


	public int getDni() {
		return dni;
	}

	public String getNombre() {
		return nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public boolean mismoDni(int dni) {
		return this.dni == dni;
	}

	
	private void setApellido(String apellido) {
		this.apellido = apellido;
	}

	private void setDni(int dni) {
		this.dni = dni;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	private void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "Paciente [dni=" + dni + ", apellido=" + apellido + ", nombre=" + nombre + ", telefono=" + telefono
				+ "]";
	}

}