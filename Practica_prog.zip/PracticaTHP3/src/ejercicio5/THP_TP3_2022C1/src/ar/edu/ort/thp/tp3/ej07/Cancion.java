package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej07;

public class Cancion {
	private static final int SEMANA = 7;
	private static final int TOPE_RESTRICCION = 1000;
	private String nombre;
	private String autor;
	private String genero;
	private int diasPublicacion;
	private int cantidadReproducciones;

	public Cancion(String nombre, String autor, String genero) {
		setNombre(nombre);
		setAutor(autor);
		setGenero(genero);
		diasPublicacion = 0;
		cantidadReproducciones = 0;
	}

	public void escuchar() {
		cantidadReproducciones++;
	}

	public boolean esRestringida() {
		return cantidadReproducciones <= TOPE_RESTRICCION && diasPublicacion <= SEMANA;
	}

	public String getAutor() {
		return autor;
	}

	public String getGenero() {
		return genero;
	}

	public String getNombre() {
		return nombre;
	}

	private void setAutor(String autor) {
		this.autor = autor;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Cancion [nombre=" + nombre + ", autor=" + autor + ", genero=" + genero + ", diasPublicacion="
				+ diasPublicacion + ", cantidadReproducciones=" + cantidadReproducciones + "]";
	}

}
