package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej07;

import java.util.ArrayList;

public class Aplicacion {
	private static final int TOPE_CANCIONES_GRATUITAS = 50;
	private ArrayList<Cancion> canciones;
	private ArrayList<Usuario> usuarios;

	/**
	 * Constructor por defecto que inicializa los ArrayList
	 */
	public Aplicacion() {
		canciones = new ArrayList<>();
		usuarios = new ArrayList<>();
	}

	private Cancion buscarCancion(String nombre, String autor) {
		Cancion cancionABuscar = null;
		int i = 0;

		while (cancionABuscar == null && i < canciones.size()) {

			if (canciones.get(i).getNombre() == nombre && canciones.get(i).getAutor() == autor) {
				cancionABuscar = canciones.get(i);
			} else {
				i++;
			}
		}
		return cancionABuscar;
	}

	private Usuario buscarUsuario(String mail) {
		Usuario usuarioABuscar = null;
		int i = 0;

		while (usuarioABuscar == null && i < usuarios.size()) {

			if (usuarios.get(i).getMail() == mail) {
				usuarioABuscar = usuarios.get(i);
			} else {
				i++;
			}
		}
		return usuarioABuscar;
	}

	public boolean altaCancion(String nombre, String autor, String tipo) {
		boolean pudeAgregar = false;

		if (buscarCancion(nombre, autor) == null) {
			pudeAgregar = canciones.add(new Cancion(nombre, autor, tipo));
		}
		return pudeAgregar;
	}

	public boolean altaUsuario(String email, String apellido, int edad, Categoria categoria) {
		boolean pudeAgregar = false;

		if (buscarUsuario(email) == null) {
			pudeAgregar = usuarios.add(new Usuario(email, apellido, edad, categoria));
		}
		return pudeAgregar;
	}

	public Resultado escucharCancion(String email, String nombre, String autor) {
		Resultado resultado = Resultado.USUARIO_INEXISTENTE;
		Usuario usuario = buscarUsuario(email);
		if (usuario != null) {
			Cancion cancion = buscarCancion(nombre, autor);
			if (cancion == null) {
				resultado = Resultado.CANCION_INEXISTENTE;
			} else {
				if (usuario.getCategoria() == Categoria.PREMIUM) {
					resultado = Resultado.OPERACION_EXITOSA;
					usuario.escucharCancion(cancion);
				} else {
					if (cancion.esRestringida()) {
						resultado = Resultado.CANCION_NO_DISPONIBLE;
					} else {
						if (usuario.getCategoria().equals(Categoria.GRATUITO)
								&& usuario.getCantidadEscuchasDiarias() > TOPE_CANCIONES_GRATUITAS) {
							resultado = Resultado.LIMITE_ALCANZADO;
						} else {
							resultado = Resultado.OPERACION_EXITOSA;
							usuario.escucharCancion(cancion);
						}
					}
				}
			}
		}
		return resultado;
	}

	public Resultado listarCancionesPorUsuario(String mail) {
		Resultado resultado = Resultado.USUARIO_INEXISTENTE;

		Usuario usuario = buscarUsuario(mail);

		if (usuario != null) {

			ArrayList<Cancion> cancionesUsuario = usuario.listarCanciones();
			if (cancionesUsuario.size() > 0) {
				for (Cancion cancion : cancionesUsuario) {
					System.out.println(cancion);
				}
			} else {
				System.out.println("EL USUARIO NO ESCUCHO AUN NINGUNA CANCION!");
			}
			resultado = Resultado.OPERACION_EXITOSA;
		}
		return resultado;
	}

	public void listarUsuarios() {
		if (usuarios.size() > 0) {
			System.out.println("LISTADO DE USUARIOS:");
			for (Usuario usuario : usuarios) {
				System.out.println(usuario);
			}
		} else {
			System.out.println("NO HAY USUARIOS REGISTRADOS!");
		}
	}

}