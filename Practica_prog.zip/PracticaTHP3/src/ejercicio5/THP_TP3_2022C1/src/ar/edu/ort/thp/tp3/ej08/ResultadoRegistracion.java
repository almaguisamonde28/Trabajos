package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej08;

public enum ResultadoRegistracion {
	TURNO_CONFIRMADO, ERROR_TURNOS_COMPLETOS, ERROR_YA_TIENE_TURNO
}
