package ejercicio5.THP_TP3_2022C1.src.ar.edu.ort.thp.tp3.ej07;

import java.util.ArrayList;

public class Usuario {
	private String mail;
	private String apellido;
	private int edad;
	private Categoria categoria;
	private ArrayList<Cancion> canciones;

	public Usuario(String mail, String apellido, int edad, Categoria categoria) {
		setMail(mail);
		setApellido(apellido);
		setEdad(edad);
		this.setCategoria(categoria);
		canciones = new ArrayList<>();
	}

	public boolean escucharCancion(Cancion cancion) {
		cancion.escuchar();
		return canciones.add(cancion);
	}

	public String getApellido() {
		return apellido;
	}

	public int getCantidadEscuchasDiarias() {
		return canciones.size();
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public int getEdad() {
		return edad;
	}

	public String getMail() {
		return mail;
	}

	public ArrayList<Cancion> listarCanciones() {
		return canciones;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	@Override
	public String toString() {
		return "Usuario [mail=" + mail + ", apellido=" + apellido + ", edad=" + edad
				+ ", cantidad de canciones escuchadas: " + canciones.size() + "]";
	}

}
