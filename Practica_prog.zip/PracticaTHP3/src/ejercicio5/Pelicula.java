package ejercicio5;

public class Pelicula {
	private String nombre;
	

}
