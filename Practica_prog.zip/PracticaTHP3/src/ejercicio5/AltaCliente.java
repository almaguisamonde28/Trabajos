package ejercicio5;

public enum AltaCliente {
	CLIENTE_EXISTENTE, CLIENTE_DEUDOR, ALTA_OK

}
