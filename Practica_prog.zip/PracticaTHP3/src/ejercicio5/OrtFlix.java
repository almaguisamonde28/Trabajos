package ejercicio5;

import java.util.ArrayList;

public class OrtFlix {

	private ArrayList<Cliente> clientes;

	private boolean buscarCliente(String dni) {
		int posActual = 0;
		int cantElementos;
		Cliente cliente1;
		boolean seEncontro = false;

		cantElementos = this.clientes.size();
		while ((seEncontro != false) && (posActual < cantElementos)) {
			cliente1 = this.clientes.get(posActual);
			if (cliente1.equals(dni)) {
				seEncontro = true;
			} else {
				posActual++;
			}
		}
		return false;
	}
	

}
