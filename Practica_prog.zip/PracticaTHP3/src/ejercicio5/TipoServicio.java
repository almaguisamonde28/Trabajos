package ejercicio5;

public enum TipoServicio {

	STANDAR, PREMIUM
}
