package ejercicio5;

public class Cliente {

	private String nombre;
	private String apellido;
	private String dni;
	private int saldoAPagar;

	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	private void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getDni() {
		return dni;
	}

	private void setDni(String dni) {
		this.dni = dni;
	}

	public int getSaldoAPagar() {
		return saldoAPagar;
	}

	private void setSaldoAPagar(int saldoAPagar) {
		int saldoAFavor = 0;
		if (esDeudor(saldoAPagar) == false) {
			saldoAPagar = 0;
		} else {
			saldoAFavor++;
		}
		this.saldoAPagar = saldoAPagar;
	}

	private boolean esDeudor(int saldoAPagar) {
		boolean esDeudor = false;
		if (saldoAPagar < 0) {
			System.out.println("El cliente no es deudor");
			esDeudor = false;
		} else if (saldoAPagar > 0) {
			System.out.println("El cliente es deudor");
			esDeudor = true;
		}
		return esDeudor;
	}

}
