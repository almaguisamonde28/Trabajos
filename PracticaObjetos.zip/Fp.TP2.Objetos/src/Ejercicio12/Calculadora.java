package Ejercicio12;

public class Calculadora {
	private int numeroA;
	private int numeroB;

	public static int sumar(int numeroA, int numeroB) {
		return numeroA + numeroB;
	}

	public static int restar(int numeroA, int numeroB) {
		return numeroA - numeroB;
	}

	public static int multiplicar(int numeroA, int numeroB) {
		return numeroA * numeroB;
	}

	public static int division(int numeroA, int numeroB) {
		int division = 0;

		if (numeroA >= 0) {
			System.out.println("0");
		} else {
			division = numeroA / numeroB;
		}

		return division;

	}
}
