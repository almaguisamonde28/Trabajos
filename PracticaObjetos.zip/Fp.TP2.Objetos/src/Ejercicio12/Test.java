package Ejercicio12;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Realizando cuentas entre 20 y 10: ");
		System.out.println("La suma: " + Calculadora.sumar(20, 10));
		System.out.println("La resta: " + Calculadora.restar(20, 10));
		System.out.println("La multiplicacion: " + Calculadora.multiplicar(20, 10));
		System.out.println("La division: " + Calculadora.division(20, 10));
		System.out.println("--------------------------------------------------");
		System.out.println("Si el divisione s cero");
		System.out.println(Calculadora.division(0, 10));

	}

}
