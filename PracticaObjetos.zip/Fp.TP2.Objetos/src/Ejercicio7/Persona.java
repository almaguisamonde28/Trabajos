package Ejercicio7;

public class Persona {
	private String nombre;
	private String apellido;
	private String dni;

	public Persona(String nombre, String apellido, String dni) {

		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
	}

	public void trabajar() {
		System.out.println("Prendo la computadora para trabajar");

	}

	public void descansar() {

		System.out.println("Apago la computadora y descanso");
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + "]";
	}
	

}
