package Ejercicio7;

public class Test {

	public static void main(String[] args) {

		Persona persona1 = new Persona("Alma", "Guisamonde", "42951769");
		Procesador proc1 = new Procesador("hp", 23456, 30);
		LectoraDvd lectora1 = new LectoraDvd("icore7", false);
		Computadora compu1 = new Computadora("Lenovo", TipoComputadora.LAPTOP, proc1, lectora1);

		System.out.println(persona1);
		persona1.descansar();
		persona1.trabajar();
		System.out.println(proc1);
		System.out.println(lectora1);
		lectora1.puedeGrabar();
		System.out.println(compu1);

	}

}
