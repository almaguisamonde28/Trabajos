package Ejercicio7;

public enum TipoComputadora {

	DESCKTOP, LAPTOP, ALL_IN_ONE;
}
