package Ejercicio7;

public class Procesador {
	final static int NIVEL_CRITICO = 80;

	private String marca;
	private Integer modelo;
	private Integer nivelActualTemperatura;

	public Procesador(String marca, Integer modelo, Integer nivelActualTemperatura) {
		this.marca = marca;
		this.modelo = modelo;
		this.nivelActualTemperatura = nivelActualTemperatura;

	}

	public void nivelCritico(Integer nivelActualTemperatura) {
		if (nivelActualTemperatura >= NIVEL_CRITICO) {
			System.out.println("El nivel de temperatura es critico");
		} else {
			System.out.println(nivelActualTemperatura);
		}
	}

	public String getMarca() {
		return marca;
	}

	private void setMarca(String marca) {
		this.marca = marca;
	}

	public Integer getModelo() {
		return modelo;
	}

	private void setModelo(Integer modelo) {
		this.modelo = modelo;
	}

	public Integer getNivelActualTemperatura() {
		return nivelActualTemperatura;
	}

	private void setNivelActualTemperatura(Integer nivelActualTemperatura) {
		this.nivelActualTemperatura = nivelActualTemperatura;
	}

	@Override
	public String toString() {
		return "Procesador [marca=" + marca + ", modelo=" + modelo + ", nivelActualTemperatura="
				+ nivelActualTemperatura + "]";
	}

	
}
