package Ejercicio7;

public class Computadora {

	private String marca;
	private TipoComputadora tipo;
	private Procesador procesador;
	private Persona persona;
	private LectoraDvd lectora;
	private boolean puedeGrabar;

	public Computadora(String marca, TipoComputadora tipo, Procesador procesador, LectoraDvd lectora) {
		this.marca = marca;
		this.tipo = tipo;
		this.procesador = procesador;
		this.lectora = lectora;

	}

	public void prender() {
		System.out.println("Prendiendo computadora...");

	}

	public void apagar() {
		System.out.println("Apagando computadora...");

	}

	public void reiniciar() {
		System.out.println("Reiniciando computadora...");
	}

	@Override
	public String toString() {
		return "Computadora [marca=" + marca + ", tipo=" + tipo + ", procesador=" + procesador + "]";
	}

}
