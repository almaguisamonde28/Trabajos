package Ejercicio7;

public class LectoraDvd {

	private String marca;
	private boolean graba = false;

	public LectoraDvd(String marca, boolean graba) {
		this.marca = marca;
		this.graba = graba;
	}

	public void puedeGrabar() {
		if (graba) {
			System.out.println("Puede grabar");
		}
	}

	@Override
	public String toString() {
		return "LectoraDvd [marca=" + marca + ", graba=" + graba + "]";
	}

}
