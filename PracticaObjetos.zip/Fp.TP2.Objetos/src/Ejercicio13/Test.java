package Ejercicio13;

public class Test {

	public static void main(String[] args) {
		System.out.println();
		SuperHeroe superHeroe1 = new SuperHeroe("Batman", 90, 70, 0);
		SuperHeroe superHereo2 = new SuperHeroe("Superman", 95, 60, 70);

		System.out.println("Compiten superheroe 1 vs superhereo2 : " + superHeroe1.competir(superHereo2));
		System.out.println("Compiten superheroe 1 vs superhereo2 : " + superHereo2.competir(superHeroe1));

	}

}
