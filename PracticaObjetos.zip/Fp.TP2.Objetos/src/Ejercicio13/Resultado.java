package Ejercicio13;

public enum Resultado {

	GANADOR, DERROTA, EMPATE;
}
