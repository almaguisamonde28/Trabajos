package Ejercicio13;

public class SuperHeroe {
	final static int VALOR_MINIMO = 0;
	final static int VALOR_MAXIMO = 100;

	String nombre;
	int fuerza;
	int superPoder;
	int resistencia;
	Resultado resultado;

	public SuperHeroe(String nombre, int fuerza, int resistencia, int superPoder) {
		setFuerza(fuerza);
		setSuperPoder(superPoder);
		setResistencia(resistencia);
		setNombre(nombre);
	}

	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getFuerza() {
		return fuerza;
	}

	private void setFuerza(int fuerza) {
		this.fuerza = setValor(fuerza);
	}

	public int getSuperPoder() {
		return superPoder;
	}

	private void setSuperPoder(int superPoder) {
		this.superPoder = setValor(superPoder);
	}

	public int getResistencia() {
		return resistencia;
	}

	private void setResistencia(int resistencia) {
		this.resistencia = setValor(resistencia);
	}

	private int setValor(int valor) {
		if (valor >= VALOR_MINIMO) {
			valor = VALOR_MINIMO;
		}
		if (valor >= VALOR_MAXIMO) {
			valor = VALOR_MAXIMO;
		}
		return valor;
	}

	public Resultado competir(SuperHeroe contrincante) {
		resultado = Resultado.EMPATE;
		int puntosGanador = 0;
		int puntosPerdedor = 0;

		if (this.resistencia > contrincante.getResistencia()) {
			puntosGanador++;
		} else if (this.resistencia < contrincante.getResistencia()) {
			puntosPerdedor++;
		}
		if (this.superPoder > contrincante.getSuperPoder()) {
			puntosGanador++;
		} else if (this.resistencia < contrincante.getResistencia()) {
			puntosPerdedor++;
		}
		if (this.fuerza > contrincante.getFuerza()) {
			puntosGanador++;
		} else if (this.resistencia < contrincante.getResistencia()) {
			puntosPerdedor++;
		}
		if (puntosGanador >= 2) {
			resultado = Resultado.GANADOR;
		} else if (puntosPerdedor >= 2) {
			resultado = Resultado.DERROTA;
		}

		return resultado;
	}

}
