package Ejercicio11;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Sacar turno");
		Turnera.otorgarProximoNumero();
		System.out.println("Tu turno es: " + Turnera.verUltimoNumeroOtorgado());
		System.out.println("Proximo turno");
		Turnera.otorgarProximoNumero();
		System.out.println("Tu turno es: " + Turnera.verUltimoNumeroOtorgado());
		Turnera.resetearContador(7);
		System.out.println("Proximo turno");
		System.out.println("Tu turno es: " + Turnera.verUltimoNumeroOtorgado());
		Turnera.resetearContador();
		System.out.println("Proximo turno");
		System.out.println("Tu turno es: " + Turnera.verUltimoNumeroOtorgado());
		Turnera.otorgarProximoNumero();
		System.out.println("Tu turno es: " + Turnera.verUltimoNumeroOtorgado());

	}

}
