package Ejercicio11;

public class Turnera {

	private static int turno = 0;

	public static void otorgarProximoNumero() {

		++turno;
	}

	public static int verUltimoNumeroOtorgado() {
		return turno;

	}

	public static void resetearContador() {
		resetearContador(0);

	}

	public static void resetearContador(int numero) {

		if (numero >= 0) {
			turno = numero;
		} else {
			System.out.println("Error");
		}

	}

}
