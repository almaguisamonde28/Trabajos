package Ejercicio10;

public class Persona {
	private String nombre;
	private Integer numeroDeTelefono;

	public Persona(String nombre, Integer numeroDeTelefono) {
		this.nombre = nombre;
		this.numeroDeTelefono = numeroDeTelefono;
	}

	public String getNombre() {
		return nombre;
	}

}
