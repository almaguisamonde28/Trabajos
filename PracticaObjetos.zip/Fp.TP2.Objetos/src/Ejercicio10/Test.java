package Ejercicio10;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Persona persona = new Persona("Alma", 112334434);
		Bot bot1 = new Bot("Carlos", persona);

		bot1.saludar(persona);
		bot1.saludar();
	}

}
