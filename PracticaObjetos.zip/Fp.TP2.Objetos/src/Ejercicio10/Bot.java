package Ejercicio10;

public class Bot {
	private String nombre;
	private Persona persona;

	public Bot(String nombre, Persona persona) {
		this.nombre = nombre;
		this.persona = persona;

	}

	public void saludar() {
		System.out.println("Hola, mi nombre es " + this.nombre + ", �En qu� puedo ayudarte?");

	}

	public void saludar(Persona persona) {
		System.out.println(
				"Hola " + persona.getNombre() + " , mi nombre es " + this.nombre + ". �En qu� puedo ayudarte?");
	}

}
