package Ejercicio1;

public class Domicilio {

	private Integer numero;
	private String calle;
	private String ciudad;

	public Domicilio(Integer numero, String calle, String ciudad) {

		setNumero(numero);
		setCalle(calle);
		setCiudad(ciudad);

	}

	public Integer getNumero() {
		return numero;
	}

	private void setNumero(Integer numero) {
		this.numero = numero;
	}

	public String getCalle() {
		return calle;
	}

	private void setCalle(String calle) {
		this.calle = calle;
	}

	public String getCiudad() {
		return ciudad;
	}

	private void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String mostrarDomicilio(String domicilio) {
		return domicilio;
	}

	@Override
	public String toString() {
		return "Domicilio [numero=" + numero + ", calle=" + calle + ", ciudad=" + ciudad + "]";
	}

}
