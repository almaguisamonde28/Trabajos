package Ejercicio1;

public class Persona {

	private String nombre;
	private String apellido;
	private String domicilio;

	public Persona(String nombre, String apellido, String domicilio) {
		nombre = "";
		apellido = "";
		domicilio = "";
	}

	public void ponerApellido(String apellido) {
		this.apellido = apellido;

	}

	public void ponerNombre(String nombre) {
		this.nombre = nombre;
	}

	public String obtenerNombreCompleto() {
		return nombre + " " + apellido;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public Domicilio mostrarDomicilio(Domicilio domicilio) {
		return domicilio;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", apellido=" + apellido + ", domicilio=" + domicilio + "]";
	}

}
