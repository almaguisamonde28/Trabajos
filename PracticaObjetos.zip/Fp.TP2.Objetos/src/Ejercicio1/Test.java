package Ejercicio1;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona persona1 = new Persona("Alma", "Guisamonde","Aconcagua 300");
		Persona persona2 = new Persona("Fulano", "Gomez", "Belgrano");
		Domicilio domicilio1 = new Domicilio(123, "Avenida libertador", "Buenos Aires");
		Domicilio domicilio2 = new Domicilio(456, "Belgrano", "Buenos aires");

		persona1.ponerNombre("Fulano");
		persona1.ponerApellido("Gomez");
		System.out.println(persona1.obtenerNombreCompleto());
		persona2.ponerNombre("Alma");
		persona2.ponerApellido("Guisamonde");
		System.out.println(persona2.obtenerNombreCompleto());
		System.out.println(persona1.mostrarDomicilio(domicilio1));
		System.out.println(persona2.mostrarDomicilio(domicilio2));

	}

}
