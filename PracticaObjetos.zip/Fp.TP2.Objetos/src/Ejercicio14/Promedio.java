package Ejercicio14;

public class Promedio {

}
