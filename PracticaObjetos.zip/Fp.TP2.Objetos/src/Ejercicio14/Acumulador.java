package Ejercicio14;

public class Acumulador {

	int cantIncremento;
	
}
