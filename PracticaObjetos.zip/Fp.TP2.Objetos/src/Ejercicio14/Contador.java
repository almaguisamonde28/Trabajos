package Ejercicio14;

public class Contador {
	static int contador = 0;

	public static int incrementar() {
		return contador++;
	}

	public static int obtenerValor() {
		return contador;
	}
}
